import json,math,heapq,xml.etree.ElementTree as E,gzip
from pathlib import Path
root=Path(__file__).resolve().parent/'data_sources';raw=json.loads((root/'railways.json').read_text())['elements'];x=E.parse(gzip.open(root/'luohu-map.osm.gz','rb')).getroot();nodes={e.attrib['id']:[float(e.attrib['lon']),float(e.attrib['lat'])] for e in x.findall('node')}
d=json.loads(Path('dist/data.js').read_text().removeprefix('window.APP_DATA=').rstrip(';\n'));allstations=json.loads((root/'stations.json').read_text())['elements'];stations={s['name']:s for s in d['stations']}
for e in allstations:
 n=e.get('tags',{}).get('name')
 if n in ['大剧院','怡景','太安'] and n not in stations:stations[n]={'name':n,'lat':e['lat'],'lon':e['lon'],'osm_id':e['id']}
def distance(a,b):return math.hypot((a[0]-b[0])*math.cos(math.radians((a[1]+b[1])/2)),a[1]-b[1])*111320
routes=[];net={'1':['罗湖','国贸','老街','大剧院'],'2':['大剧院','湖贝','黄贝岭'],'5':['黄贝岭','怡景','太安','布心'],'3':['老街','晒布','翠竹','水贝']}
for line,names in net.items():
 graph={};coords={}
 for e in raw:
  if e.get('tags',{}).get('name')!='深圳地铁'+line+'号线':continue
  pairs=list(zip(e.get('nodes',[]),e.get('geometry',[])))
  for nid,c in pairs:coords[nid]=[c['lon'],c['lat']]
  for (a,ca),(b,cb) in zip(pairs,pairs[1:]):
   w=distance(coords[a],coords[b]);graph.setdefault(a,[]).append((b,w));graph.setdefault(b,[]).append((a,w))
 for a,b in zip(names,names[1:]):
  s,t=stations[a],stations[b]
  def projected(station):
   pt=[station['lon'],station['lat']];answers=[]
   for v,links in graph.items():
    for n,w in links:
     if v>n:continue
     A,B=coords[v],coords[n];cx=math.cos(math.radians(pt[1]));dx=(B[0]-A[0])*cx;dy=B[1]-A[1];den=dx*dx+dy*dy
     f=max(0,min(1,(((pt[0]-A[0])*cx)*dx+(pt[1]-A[1])*dy)/den)) if den else 0
     P=[A[0]+(B[0]-A[0])*f,A[1]+(B[1]-A[1])*f];answers.append((distance(pt,P),v,n,P))
   return sorted(answers)[:4]
  best=None
  for accessS,sv,sn,S in projected(s):
   for accessT,tv,tn,T in projected(t):
    if max(accessS,accessT)>200:continue
    g={k:list(v) for k,v in graph.items()};cc={**coords,-1:S,-2:T}
    for temp,v,n,P in [(-1,sv,sn,S),(-2,tv,tn,T)]:
     g[temp]=[(v,distance(P,coords[v])),(n,distance(P,coords[n]))];g[v].append((temp,distance(P,coords[v])));g[n].append((temp,distance(P,coords[n])))
    if {sv,sn}=={tv,tn}:g[-1].append((-2,distance(S,T)));g[-2].append((-1,distance(S,T)))
    heap=[(0,-1)];cost={-1:0};parent={}
    while heap:
     cost0,v=heapq.heappop(heap)
     if cost0!=cost[v]:continue
     if v==-2:break
     for n,w in g.get(v,[]):
      if cost0+w<cost.get(n,1e99):cost[n]=cost0+w;parent[n]=v;heapq.heappush(heap,(cost[n],n))
    if -2 not in cost:continue
    total=cost[-2]+accessS+accessT
    if best is None or total<best[0]:
     path=[-2]
     while path[-1]!=-1:path.append(parent[path[-1]])
     best=(total,[cc[i] for i in path[::-1]],cost[-2])
  if best:routes.append({'line':line,'from':a,'to':b,'geometry':{'type':'LineString','coordinates':best[1]},'distance':round(best[2]),'basis':'当前OSM轨道参考，非2023通行记录','stopCount':2 if line=='3' and {a,b}=={'翠竹','水贝'} else 1,'viaStops':['田贝'] if line=='3' and {a,b}=={'翠竹','水贝'} else []});print(line,a,b,len(best[1]),round(best[2]))
  else:print('MISSING',line,a,b)
places=[];roads=[]
for e in x:
 tags={a.attrib['k']:a.attrib['v'] for a in e.findall('tag')};n=tags.get('name')
 if not n:continue
 if e.tag=='node':c=nodes.get(e.attrib['id'])
 elif e.tag=='way':ps=[nodes[z.attrib['ref']] for z in e.findall('nd') if z.attrib['ref'] in nodes];c=[sum(p[0] for p in ps)/len(ps),sum(p[1] for p in ps)/len(ps)] if ps else None
 else:continue
 if not c:continue
 if tags.get('amenity') in ['hospital','school'] or tags.get('place') in ['suburb','neighbourhood','quarter','locality']:
  places.append({'name':n,'lon':c[0],'lat':c[1],'kind':tags.get('amenity') or tags.get('place'),'osm_type':e.tag,'osm_id':e.attrib['id'],'coordinate_basis':'公开POI点／建筑或区域代表位置，非入口定位'})
 if e.tag=='way' and tags.get('highway') in ['primary','secondary','tertiary','residential'] and n in ['嘉宾路','建设路','爱国路','文锦中路','沿河南路']:
  roads.append({'name':n,'coordinates':[nodes[z.attrib['ref']] for z in e.findall('nd') if z.attrib['ref'] in nodes],'osm_id':e.attrib['id']})
byname={p['name']:p for p in places};hospital=byname.get('深圳市人民医院') or byname.get('人民医院留医部');
if hospital:byname['深圳人民医院']={**hospital,'name':'深圳人民医院','alias_of':hospital['name']}
features=json.loads((root/'districts.geojson').read_text())['features'];luohu=next(f for f in features if f['properties']['name']=='罗湖区')
out={'stations':list(stations.values()),'edges':routes,'places':list(byname.values()),'roads':roads,'area_reference':luohu,'collected_at':'2026-10-12','license':'© OpenStreetMap contributors · ODbL','source':'https://www.openstreetmap.org/','area_source':'已收集DataV区界参考，不作为精确淹没范围','network_note':'仅选2023已存在的1号线罗湖—大剧院、2号线大剧院—黄贝岭、5号线黄贝岭—布心走廊；不纳入5号线2025年西延。轨迹来自当前公开地理数据。'}
previous=Path('dist/reference-network.js');prior=json.loads(previous.read_text().removeprefix('window.REFERENCE_NETWORK=').rstrip(';')) if previous.exists() else {};out['driving_samples']=prior.get('driving_samples',[])
Path('dist/reference-network.js').write_text('window.REFERENCE_NETWORK='+json.dumps(out,ensure_ascii=False)+';');print('places',len(byname),'roads',len(roads),'edges',len(routes))
