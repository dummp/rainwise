# 历史来源核对记录（2026-10-12）

## 时间精度修订
- 深圳市水务局《深圳雨情最新进展！多部门紧急处置》另一正文页面明确发布时间2023-09-08 00:17：https://swj.sz.gov.cn/xxgk/zfxxgkml/yjgl/content/post_10824841.html 。E001—E004改用此带时分来源；不将报道时间当作暂停开始时刻。
- 2023-09-08 09:28公告：https://www.sz.gov.cn/szzt2010/zdlyzl/scaq/yf/content/post_10824929.html 。包含1、2&8、3、5、9号线部分区段，E013—E015使用此时间明确的同文来源。新增红色预警当时仍生效、专业判断、停课、出行建议摘要。
- 00:17报道记载盐田正坑站过去3小时最大滑动雨量234.9毫米；统计终点未给出。不作为罗湖当前雨强。
- 11:58报道：https://www.sz.gov.cn/cn/xxgk/zfxxgj/zwdt/content/post_10825070.html 。梧桐村最大1小时雨量116.8毫米等报道统计只能在11:58以后展示。水库00:15泄洪事件与11:58来源发布时间分开记录。
- 事后气象局报道仍保留2023-09-15 14:30:15可用时间：https://weather.sz.gov.cn/mobile/xinxigongkai/gongzuodongtai/content/post_10837589.html 。不把回顾中的原预警时刻当成该网页当时已公开。

## 公益资料
壹基金机构原始救援公告：https://onefoundation.cn/news/64fa08da7c558f6a51/ 。仅有2023-09-08日期，严格视角按当日23:59:59启用。公布99人备勤与救援行动；不是专属募捐公告或到账收据。未取得本次深圳暴雨募捐金额/到账明细，不使用其他地区救灾或年度总额填充。

## 数据范围
27条事件摘要、40条四版罗湖街道指引、11个OSM公开站点和ERA5 G03事件期间72小时背景。医院场景用已有指引进行文字匹配，医院入口定位尚未核验。网页摘要人工整理不构成实时数据流。prepare_data.py原始数据重建脚本尚未包含本次核对修订；发布版本以dist/data.js为准。

# 第十二版数据处理说明（2026-10-13）
- weather_code：Open-Meteo Forecast API官方文档 https://open-meteo.com/en/docs ，WMO天气状态，仅用于天气标注，不转成积涝概率。
- build_export_map.py从已保存的luohu-map.osm.gz提取道路/建筑/水系/绿地形成export-map-data.js。采集范围22.530—22.560N、114.100—114.135E，保留延伸ways节点；不代表深圳全域，也不代表历史灾时路网。署名OpenStreetMap contributors / ODbL，数据原件不改动。
- 隐患匹配只是指引名称候选关联，未取得可用于精确线面相交的官方隐患几何；去掉黄贝岭站→黄贝街道的名称相似推断。

# 第十三版示例与地点说明（2026-10-13）
- 反馈、回复、任务、材料申请与评价样例均为根据当时情况编写的虚构操作案例；背景关联SZ-E022的2023-09-08 09:28官方出行建议，09:29作为演示可见时刻，不是实际居民/机构记录。
- 机构任务只提供明确“虚构演示”的格式示例，没有真实委托授权。奖励无实际履约。
- event-regions.js复用既有data_sources/districts.geojson行政区地理数据。地图行政区不是积水面；区域中心仅在用户主动输入行政区时作为位置参考并警告精度。距离采用点位直线参考与区界近似距离，不作为导航距离。

# 第十四版产品反馈参考（2026-10-13）
软件反馈独立于灾情反馈。表单设计参考公开产品帮助文档中的问题/建议分类、复现过程与可选附件：
- Microsoft Feedback Hub: https://support.microsoft.com/en-us/windows/apps/send-feedback-to-microsoft-with-the-feedback-hub-app
- Google Maps product feedback/help: https://support.google.com/maps/answer/3094045
FAQ与页面文案按深雨知路实际能力原创编写；未假设有客服接收、官方提交或后台推送。
