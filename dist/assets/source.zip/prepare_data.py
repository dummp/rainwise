import json,csv
from pathlib import Path
src=Path('/workspace/scratch/f390e99c8b6f/shenzhen_climate_data');out=Path('/workspace/sites/shenyuzhilu/dist')
r=[x for x in json.loads((src/'10_processed/street_rainfall_thresholds_2023_2026.json').read_text()) if x['district']=='罗湖区']
names=['罗湖','国贸','老街','湖贝','黄贝岭','莲塘','翠竹','晒布','水贝','布心','文锦']
seen=set();stations=[]
for x in json.loads((src/'06_places/osm_stations_bbox.json').read_text())['elements']:
 n=x.get('tags',{}).get('name')
 if n in names and n not in seen:stations.append({'name':n,'lat':x['lat'],'lon':x['lon'],'osm_id':x['id']});seen.add(n)
e=json.loads((src/'10_processed/historical_event_annotations.json').read_text())
for x in e:
 p=x['source_published_at'];x['available_at']=p if 'T' in p else p+'T23:59:59+08:00'
weather=[]
with (src/'10_processed/era5_event_20230828_20230910.csv').open(encoding='utf-8-sig') as f:
 for x in csv.DictReader(f):
  if x['grid_id']=='G03' and '2023-09-07'<=x['time_local'][:10]<='2023-09-09':weather.append({'time':x['time_local'],'rain':float(x['precipitation'])})
data={'risks':r,'stations':stations,'events':e,'weather':weather,'collected_at':'2026-10-11','guide_dates':{'2023':'2023-05-19','2024':None,'2025':None,'2026':'2026-06-12'}}
(out/'data.js').write_text('window.APP_DATA='+json.dumps(data,ensure_ascii=False)+';')
