"""Build bounded export context from preserved OSM source; no tile downloads."""
import gzip,json,xml.etree.ElementTree as E
from pathlib import Path
root=E.fromstring(gzip.open('data_sources/luohu-map.osm.gz','rb').read())
nodes={n.attrib['id']:[round(float(n.attrib['lon']),6),round(float(n.attrib['lat']),6)] for n in root.findall('node')}
features=[]
for w in root.findall('way'):
 tags={t.attrib['k']:t.attrib['v'] for t in w.findall('tag')}
 kind='road' if 'highway' in tags else 'water' if tags.get('natural')=='water' or 'waterway' in tags else 'green' if tags.get('leisure')=='park' or tags.get('landuse') in ['forest','grass','recreation_ground'] else 'building' if 'building' in tags else None
 if not kind:continue
 refs=[x.attrib['ref'] for x in w.findall('nd')]
 if any(r not in nodes for r in refs):continue
 coords=[nodes[r] for r in refs]
 if len(coords)<2:continue
 features.append({'kind':kind,'name':tags.get('name:zh') or tags.get('name',''),'class':tags.get('highway',''),'closed':refs[0]==refs[-1],'coordinates':coords})
b=root.find('bounds').attrib
out={'bounds':{k:float(v) for k,v in b.items()},'features':features,'source':'Preserved OSM extract 2026-10-12; current reference, not 2023 road condition'}
Path('dist/export-map-data.js').write_text('window.EXPORT_MAP_DATA='+json.dumps(out,ensure_ascii=False,separators=(',',':'))+';\n')
print('Export context features:',len(features),'bytes:',Path('dist/export-map-data.js').stat().st_size)
