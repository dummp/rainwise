# 公益项目插画生成说明

2026-10-13，使用内置 imagegen 生成三张插画，已经放入现有 Demo。它们是概念插画，不是灾害现场照片，也不对应真实募捐项目。

## 保存位置

- `/workspace/scratch/4553f0f60eda/site-current/dist/assets/relief-kits.png`
- `/workspace/scratch/4553f0f60eda/site-current/dist/assets/shelter-care.png`
- `/workspace/scratch/4553f0f60eda/site-current/dist/assets/community-cleanup.png`

## 原始提示词

### 应急生活包

Use case: illustration-story. Asset type: landscape charity project card illustration for a Chinese flood resilience Demo. Subject: neatly prepared emergency household supply kits on a dry indoor community center table: drinking water, packaged meals, hygiene supplies, torch, first-aid pouch, warm simple composition. Hand-painted editorial illustration with soft paper texture, restrained teal and cream palette and small ochre accents, warm empathetic mood, Shenzhen-like community setting hinted through a window, horizontal 3:2 composition. No text, no logos, no charity brand, no money, no suffering people, no documentary realism. This is fictional conceptual illustration, not a photograph of an actual relief operation.

### 临时安置用品

Use case: illustration-story. Asset type: landscape charity project card illustration matching a Chinese flood resilience Demo. Subject: clean temporary community shelter corner with neatly folded blankets, sleeping mats, modest bedding kits, family hygiene packs, lantern; volunteers' hands arranging supplies, no identifiable faces. Hand-painted editorial illustration with soft paper texture, restrained teal, sage and cream palette, small ochre accents, calm humane warm mood, horizontal 3:2 composition. No text, no logos, no charity branding, no documentary realism, no injured or suffering people. A fictional conceptual AI illustration.

### 社区清理物资

Use case: illustration-story. Asset type: landscape charity project card illustration for Chinese urban flood resilience Demo. Subject: gloves, rubber boots, cleaning buckets, brooms and disinfectant supplies ready inside a dry community equipment room, view onto a calm urban courtyard after rain, no floodwater or active rescue. Hand-painted editorial illustration with soft paper texture, restrained teal, sage and cream palette and small ochre accents, warm hopeful mood, horizontal 3:2 composition. No text, logos, recognizable organizations, photoreal documentary style, or people in dangerous floodwater. A fictional conceptual AI illustration.
