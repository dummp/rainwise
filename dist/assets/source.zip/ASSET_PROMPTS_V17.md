# 公益进展插画 · 第十七版

使用内置 imagegen 生成。全部为虚构模拟进展的概念插画，不是实际采购、发放或签收证明。

## giving-procurement

保存位置：`/workspace/scratch/4553f0f60eda/site-current/dist/assets/giving-procurement.png`

原始提示词：

Use case: illustration-story. Asset type: landscape progress illustration for a Chinese urban flood resilience charity simulation Demo. Orderly dry indoor community storeroom: volunteers' hands checking a neatly arranged delivery of sealed water bottles, folded blankets, hygiene kits and cleaning gloves; unbranded cardboard boxes and a clipboard with abstract blank markings. Shows fictional supplies being prepared and counted. Hand-painted editorial illustration, delicate paper texture, muted teal, sage, cream and ochre accents, warm daylight, horizontal 3:2 composition. Match a calm Chinese community care website. No text, readable paperwork, logos, real charity names, monetary symbols, flooding, danger, documentary photographs, injury or distressed people. These are clearly conceptual AI illustrations for fictional simulated procurement, delivery and follow-up, never evidence of actual aid.

## giving-delivery

保存位置：`/workspace/scratch/4553f0f60eda/site-current/dist/assets/giving-delivery.png`

原始提示词：

Use case: illustration-story. Asset type: landscape progress illustration for a Chinese urban flood resilience charity simulation Demo. Safe dry community shelter doorway: anonymous volunteers handing an unbranded cardboard supplies box to a family's hands, folded blanket and packaged water visible, warm respectful community atmosphere, no identifiable faces or suffering people. Shows a fictional receipt of supplies. Hand-painted editorial illustration, delicate paper texture, muted teal, sage, cream and ochre accents, warm daylight, horizontal 3:2 composition. Match a calm Chinese community care website. No text, readable paperwork, logos, real charity names, monetary symbols, flooding, danger, documentary photographs, injury or distressed people. These are clearly conceptual AI illustrations for fictional simulated procurement, delivery and follow-up, never evidence of actual aid.

## giving-followup

保存位置：`/workspace/scratch/4553f0f60eda/site-current/dist/assets/giving-followup.png`

原始提示词：

Use case: illustration-story. Asset type: landscape progress illustration for a Chinese urban flood resilience charity simulation Demo. Warm dry home/community room: donated-style fictional supplies unpacked and arranged for use, blankets, water, hygiene kits and gloves; hands arranging a simple abstract inventory sheet with no readable text and a small potted plant. Shows a fictional use follow-up, no identifiable faces. Hand-painted editorial illustration, delicate paper texture, muted teal, sage, cream and ochre accents, warm daylight, horizontal 3:2 composition. Match a calm Chinese community care website. No text, readable paperwork, logos, real charity names, monetary symbols, flooding, danger, documentary photographs, injury or distressed people. These are clearly conceptual AI illustrations for fictional simulated procurement, delivery and follow-up, never evidence of actual aid.
