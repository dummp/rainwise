"""Package the existing buildless demo as one downloadable HTML file."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import base64,re,json,hashlib
ROOT=Path(__file__).resolve().parent
DIST=ROOT/'dist'
OUT=ROOT.parent.parent/'shenyuzhilu-new-demo.html'
# Rebuild the downloadable text-only source archive; no data from localStorage.
with ZipFile(DIST/'source.zip','w',ZIP_DEFLATED) as z:
    for p in sorted(ROOT.rglob('*')):
        if p.is_file() and p.name!='STANDALONE_MANIFEST.json' and p.suffix in ['.js','.css','.html','.json','.geojson','.py','.md','.cjs']:
            z.write(p,p.relative_to(ROOT))
assets={str(p.relative_to(DIST)):'data:image/png;base64,'+base64.b64encode(p.read_bytes()).decode() for p in (DIST/'assets').glob('*.png')}
assets['source.zip']='data:application/zip;base64,'+base64.b64encode((DIST/'source.zip').read_bytes()).decode()
html=(DIST/'index.html').read_text()
script_count=0

def script(m):
    global script_count
    p=(DIST/m[1].split('?')[0]).resolve()
    assert p.is_relative_to(DIST)
    content=p.read_text()
    for path,url in assets.items():content=content.replace(path,url)
    content=re.sub(r'</script',r'<\\/script',content,flags=re.I)
    script_count+=1
    return '<script>\n'+content+'\n</script>'

def style(m):
    p=(DIST/m[1].split('?')[0]).resolve()
    assert p.is_relative_to(DIST)
    return '<style>\n'+p.read_text()+'\n</style>'
html=re.sub(r'<script src="([^"]+)"\s*></script>',script,html)
html=re.sub(r'<link rel="stylesheet" href="([^"]+)"\s*>',style,html)
html=html.replace('<title>深雨知路 · 罗湖暴雨出行助手</title>','<title>深雨知路 · 新版本地体验</title>')
# Local sharing creates a saved HTML download rather than an unusable file URL.
bootstrap='''<script>
window.RAINWISE_STANDALONE=true;
</script>'''
html=html.replace('<body data-booting>','<body data-booting>'+bootstrap)
local_extension='''<script>
const standaloneRenderBase=vRender;
vRender=function(){standaloneRenderBase();const foot=document.querySelector('.sidefoot');if(foot)foot.insertAdjacentHTML('beforeend',`<p class="muted" style="font-size:11px;line-height:1.6">${v20Text('本地体验版 · 天气、地图需联网。记录与原网站分开保存。','Local demo · Weather and maps require internet. Records are separate from the hosted site.')}</p>`)};
// Stop local share before older capture handlers run, while preserving all other clicks.
window.addEventListener('click',e=>{const b=e.target.closest('[data-v2="share"]');if(!b)return;e.preventDefault();e.stopImmediatePropagation();toast(v20Text('本地体验版请分享HTML文件；网址快照请在正式站点使用。','Share this HTML file for local viewing. URL snapshots require the hosted site.'));},true);
</script>'''
html=html.replace('<script>document.body.removeAttribute',local_extension+'<script>document.body.removeAttribute')
from html.parser import HTMLParser
class ResourceCheck(HTMLParser):
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        assert not (tag=='script' and 'src' in a)
        assert not (tag=='link' and a.get('rel')=='stylesheet')
ResourceCheck().feed(html)
OUT.write_text(html)
manifest={'output':OUT.name,'sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),'inline_scripts':script_count,'inline_assets':len(assets)-1,'source_archive_bytes':(DIST/'source.zip').stat().st_size,'notes':'External model weather, live map tiles and routing still require network. Local file storage is distinct from the hosted origin. No user localStorage is embedded.'}
(ROOT/'STANDALONE_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
print(json.dumps(manifest,ensure_ascii=False))
